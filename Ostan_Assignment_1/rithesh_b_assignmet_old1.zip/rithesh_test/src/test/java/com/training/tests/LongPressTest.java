package com.training.tests;

import com.training.TestBaseFirst;
import com.training.doubleTap.DoubleTap;
import com.training.home.Home;
import com.training.longpress.LongPress;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LongPressTest extends TestBaseFirst {

    public Home home;
    public LongPress longPress;

    @BeforeClass
    public void init(){
        home = new Home(driver);
        longPress = new LongPress(driver);
    }

    @Test
    public void longPressTestCase() throws InterruptedException {

        home.goToLongPressOption();

        System.out.println("Before LongPress --> ");

        Assert.assertTrue(longPress.longPressAction());

    }
}