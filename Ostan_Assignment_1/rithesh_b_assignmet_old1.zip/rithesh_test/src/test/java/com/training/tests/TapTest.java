package com.training.tests;

import com.training.TestBaseFirst;
import com.training.home.Home;
import com.training.tap.Tap;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.*;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class TapTest extends TestBaseFirst {

    public Tap tap;
    public Home home;

    @BeforeClass
    public void init(){
        tap = new Tap(driver);
        home = new Home(driver);
    }

    @Test
    public void tapTestCase() throws InterruptedException {

        home.goToTapOption();

        System.out.println("Before Clicking --> ");

        Assert.assertTrue(tap.tapAction());

    }
}